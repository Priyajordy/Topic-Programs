#include<stdio.h>
#include<stdlib.h>

#pragma pack(1)

struct node
{
    int data;
    struct node *next;  // self referential
};

typedef struct node NODE;
typedef struct node * PNODE;
typedef struct node ** PPNODE;
// All Declaration are global. Easy to access for all functions

void InsertLast(PPNODE First, int no)
{
    PNODE newn = (PNODE)malloc(sizeof(NODE));// 1 Allocate memory

    PNODE temp = *First; 

    newn -> data = no;
    newn -> next = NULL;

    if(*First == NULL)  // If linked list is empty
    {
        *First = newn;
    }
    else                // If linked list contains atleast one node
    {
        while(temp -> next != NULL)
        {
            temp = temp -> next;
        }

        temp -> next = newn;
    }
}

void Display(PNODE First)
{
    printf("Elements from the linked list are : \n");

    while(First != NULL)
    {
        printf("| %d |->",First->data);
        First = First -> next;
    }
    printf("NULL \n");
}

int Maximum(PNODE First)
{
    int iMax = 0;

    if(First == NULL)
    {
        printf("Linked List is empty \n");
        return 0;
    }

    iMax = First->data; 

    while(First != NULL)
    {
        if((First->data) > iMax)
        {
            iMax = First->data;            
        }
        First = First->next;
    }
    return iMax;
}

int main()
{
    int iRet = 0;
    PNODE Head = NULL;

    iRet = Maximum(Head);
    printf("Largest number in linked list is : %d\n",iRet); // No output
    // Means :- Code Abnormally band padala:- Segmentation fault mhantat
    
    InsertLast(&Head, 11); 
    InsertLast(&Head, 21); 
    InsertLast(&Head, 51); 
    InsertLast(&Head,101);
    InsertLast(&Head,111);
    InsertLast(&Head,121);
    Display(Head);

    iRet = Maximum(Head);
    printf("Largest number in linked list is : %d\n",iRet);

    return 0;
}
