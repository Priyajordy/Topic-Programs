#include<stdio.h>
#include<stdlib.h>

#pragma pack(1)

struct node
{
    int data;
    struct node *next;
    struct node *prev;      // X (new line- compared to SinglyLinkedList)
};

typedef struct node NODE;
typedef struct node *PNODE;
typedef struct node **PPNODE;

void InsertFirst(PPNODE First, int no)
{
    PNODE newn = (PNODE)malloc(sizeof(NODE));

    newn -> data = no;
    newn -> next = NULL;
    newn -> prev = NULL;    // X

    if(*First == NULL)
    {
        *First = newn;      // Book madhali case A
    }
    else
    {
        newn -> next = *First;
        (*First) -> prev = newn;    // X
        *First = newn;
    }

}

void InsertLast(PPNODE First, int no)
{
    PNODE newn = (PNODE)malloc(sizeof(NODE));
    PNODE temp = *First;

    newn -> data = no;
    newn -> next = NULL;
    newn -> prev = NULL;    // X

    if(*First == NULL)
    {
        *First = newn;      // Book madhali case A
    }
    else
    {
        while(temp -> next != NULL)
        {
            temp = temp -> next;
        }
        temp -> next = newn;
        newn -> prev = temp;    // X
    }

}

void DeleteFirst(PPNODE First)
{
    if(*First == NULL)  // LL is empty
    {
        return;
    }
    else if((*First) -> next == NULL)   // LL contains 1 node
    {
        free(*First);
        *First = NULL;
    }
    else    // LL contains more than 1 node
    {
        *First = (*First) -> next;
        free((*First) -> prev);      // X
        (*First) -> prev = NULL;    // X
    }
}

void DeleteLast(PPNODE First)
{
    PNODE temp = *First;

    if(*First == NULL)  // LL is empty
    {
        return;
    }
    else if((*First) -> next == NULL)   // LL contains 1 node
    {
        free(*First);
        *First = NULL;
    }
    else    // LL contains more than 1 node
    {
        while(temp->next->next != NULL)
        {
            temp = temp -> next;
        }
        free(temp -> next);
        temp -> next = NULL;
    }
}

void Display(PNODE First)
{
    printf("Elements from the linked list are : \n");
    printf("NULL <=>");
    while(First != NULL)
    {
        printf("| %d |<=>",First -> data);
        First = First -> next;
    }
    printf("NULL \n");
}

int Count(PNODE First)
{
    int iCnt = 0;

    while(First != NULL)
    {
        iCnt++;
        First = First -> next;
    }
    return iCnt++;
}

void InsertAtPos(PPNODE First, int no, int ipos)
{
    int NodeCnt = 0;
    int iCnt = 0;
    PNODE newn = NULL;
    PNODE temp = NULL;

    NodeCnt = Count(*First);   

    if((ipos < 1) || (ipos > (NodeCnt + 1))) // Filter
    {
        printf("Invalid Position\n");
        return;
    }
    if(ipos == 1) // if : else if he related ahet
    {
        InsertFirst(First, no);
    }
    else if(ipos == NodeCnt+1)
    {
        InsertLast(First, no);
    }
    else
    {
        newn = (PNODE)malloc(sizeof(NODE));

        newn -> data = no;
        newn -> next = NULL;
        newn -> prev = NULL;    // X

        temp = *First;

        for(iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp = temp -> next;
        }
        newn -> next = temp -> next;
        temp->next->prev = newn;    // X
        temp -> next = newn;
        newn -> prev = temp;        // X
    }
}

void DeleteAtPos(PPNODE First,int ipos)
{
    PNODE temp1 = NULL;
    PNODE temp2 = NULL; // nasel tr physically free krta yenar nahi
    int iCnt = 0,NodeCnt = 0;

    NodeCnt = Count(*First);

    if((ipos < 1) || (ipos > (NodeCnt))) // Filter
    {
        printf("Invalid Position\n");
        return;
    }
    if(ipos == 1)
    {
        DeleteFirst(First);
    }
    else if(ipos == NodeCnt)
    {
        DeleteLast(First);
    }
    else
    {
        temp1 = *First;

        for(iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp1 = temp1 -> next;
        }
        temp2 = temp1 -> next;

        temp1 -> next = temp2 -> next; // temp->next = temp->next->next;
        temp2->next->prev = temp1;  // X

        free(temp2);
    }
}

int main()
{
    int iRet = 0;
    PNODE Head = NULL;

    InsertFirst(&Head,51);
    Display(Head);

    InsertFirst(&Head,21);
    Display(Head);

    InsertFirst(&Head,11);
    Display(Head);

    InsertLast(&Head,101);
    Display(Head);

    InsertLast(&Head,111);
    Display(Head);

    InsertLast(&Head,121);
    Display(Head);

    iRet = Count(Head);
    printf("Number of elements are : %d\n",iRet);

    InsertAtPos(&Head,105,5);
    Display(Head);
    DeleteAtPos(&Head,5);
    Display(Head);

    DeleteFirst(&Head);
    DeleteLast(&Head);

    Display(Head);

    iRet = Count(Head);
    printf("Number of elements are : %d\n",iRet);

    return 0;
}