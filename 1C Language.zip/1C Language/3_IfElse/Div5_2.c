////////////////////////////////////////////////////////////////////////
// steps to follow while programming
///////////////////////////////////////////////////////////////////////

// step 1	:	Understand the problem statement
// step 2	:	Write the algorithm
// step 3	:	Decide the programming language
// step 4	:	write the program
// step 5	:	test the program

/////////////////////////////////////////////////////////////////////
// Problem statement : Accept the number from user and check whether it is divisible by 5 or not
// Input : 23
// Output : 23 is not divisible by 5
//
// Input : 25
// Output : 25 is not divisible by 5
//
// Input : -20
// Output : -20 is not divisible by 5
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////
// Algorithm
///////////////////////////////////////////////////////////////////////

/*
	START
		Accept number from user as No
		Divide that No by 5 and check the value of reminder
		If the value is 0
			Then display as No is divisible by 5
		Otherwise
			Display as No is not divisible by 5

	END
*/

////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>

////////////////////////////////////////////////////////////////////////
// 
// Function Name:	DivisibleByFive
// Description	:	To check whether the input is divisible by 5 or not
// Input		:	Integer
// Output		:	Integer
// Author		:	Shweta Balaram Jadhav (1377)
// Date			:	12/10/2022
//
////////////////////////////////////////////////////////////////////////

bool DivisibleByFive(int iNo)
{
	int iAns = 0;
	iAns = iNo % 5;
	
	if(iAns == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}


//////////////////////////////////////////////////////////////////////////
// Entry point of the application
///////////////////////////////////////////////////////////////////////

int main()
{
	int iValue = 0;
	bool bRet = false;
	
	printf("Enter the number : \n");
	scanf("%d",&iValue);
	
	bRet = DivisibleByFive(iValue);
	
	if(bRet == false)
	{
		printf("%d is not divisible by 5 \n",iValue);
	}
	else
	{
		printf("%d is divisible by 5 \n",iValue);
	}
	
	return 0;
}


////////////////////////////////////////////////////////////////////////////
// Result
//
// Input : 25
// Output : 25 is not divisible by 5
//
////////////////////////////////////////////////////////////////////////////
